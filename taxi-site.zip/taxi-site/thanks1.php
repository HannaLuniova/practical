<?php
echo "<h1 style='font-size: 220%; text-align: center; margin-top: 100px; font-family: monospace; color: #ff0000'>Спасибо за регистрацию!!!</h1> <br><br><br>";
echo "<button style='margin: 100px 0px 0px 680px; height: 40px; background-color: green; text-align: center;' ><a style='text-decoration: none; color: aliceblue'  href='index.html' class='btn btn-success'>Вернуться на главную страницу</a></button>";

